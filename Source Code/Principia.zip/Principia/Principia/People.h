//
//  People.h
//  Principia
//
//  Created by Shirley Paulson on 11/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface People : UITableViewController

@end
